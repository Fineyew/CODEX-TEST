'use strict';

global.Promise = require('bluebird');

const fs = require('fs');
const path = require('path');
const axios = require('axios');
const Eris = require('@dyno.gg/eris');
/* ... core setup, collections, managers, IPC, dispatcher ... */